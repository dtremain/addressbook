<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "XHTML1-s.dtd">

<html>
<head>
<title>Asset Inventory</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="./css/style.css" />
 <script type="text/javascript" src="ie5.js"></script>
 <script type="text/javascript" src="./javascripts/XulMenu.js"></script>
</head>
<body>

<div id="header">
	<img src="./images/top.jpg" />
	<h1>NF Change Order Form</h1>
	

</div>

<div id="bar">

        <table  id="menu1" class="XulMenu">
        <tr>
            <td>
                <a class="button" href="addressbook.php">Address book</a>
                
            </td>
			
			<td>
                <a class="button" href="NFContracts.php">NF Contracts</a>
                
            </td>
			
			<td>
                <a class="button" href="FEContracts.php">FE Contracts</a>
                
            </td>
			
			<td>
                <a class="button" href="NFChangeOrders.php">NF Change Order</a>
                
            </td>
			
			
        </tr>
        </table>


    </div>
	
 <script type="text/javascript">
    var menu1 = new XulMenu("menu1");
    
    menu1.init();
    </script>


<div id="container">

	<div id="primarycontainer">
	
	<p> Welcome to the OmniSource corporation Contract Forms. </P>
	
		
	</div>

	<div id="secondarycontent">

		
	
		

		

	</div>

	<div class="clearit"></div>

</div>

<div id="footer">
	&copy; 2011 Omnisource. 
</div>


</body>
</html>
