<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "XHTML1-s.dtd">

<html>
<head>
<title>Contracts</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="../css/style.css" />
 <script type="text/javascript" src="ie5.js"></script>
 <script type="text/javascript" src="../javascripts/XulMenu.js"></script>
 <script src="../javascripts/jquery.js"></script>
 <script src="../javascripts/nonscrapcopyaddress.js"></script>
 
	<script type="text/javascript">

		function stopRKey(evt) {
		  var evt = (evt) ? evt : ((event) ? event : null);
		  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
		  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;}
		}

		document.onkeypress = stopRKey;

	</script>
 
 
</head>
<body>

<div id="header">
	<img src="../images/top.jpg" />
	<h1>Address Book Form</h1>
	

</div>

<div id="bar">

        <table  id="menu1" class="XulMenu">
        <tr>
            <td>
                <a class="button" href="addressbook.php">Address book</a>
                
            </td>
			
			<td>
                <a class="button" href="NFContracts.php">NF Contracts</a>
                
            </td>
			
			<td>
                <a class="button" href="FEContracts.php">FE Contracts</a>
                
            </td>
			
			<td>
                <a class="button" href="NFChangeOrders.php">NF Change Order</a>
                
            </td>
			
			
        </tr>
        </table>


    </div>
	
 <script type="text/javascript">
    var menu1 = new XulMenu("menu1");
    
    menu1.init();
    </script>



<div id="container">

	<div id="primarycontainer">
	
	  	  
	  <form  name="addressform" method="POST" action="addressbookemail.php">
	  
			<input type="hidden" name="stype" value="nonscrap" />				
			<fieldset >
				<legend><font size="2" ><b>Non-Trade </b></font></legend>
				<table width="100%" cellpadding="10" cellspacing="0" border="0">
				<tr><td width="25%">
				<input type="radio" name="nontrade" value="NEW ADDITION"> New Addition</td>
				<td width="25%">
				<input type="radio" name="nontrade" value="MODIFICATION"> Modification</td>
				
				</tr>
				</table>
				</fieldset><br>
				
			<fieldset >
				<legend><font size="2" ><b>Non-Trade Type </b></font></legend>
				<table width="100%" cellpadding="10" cellspacing="0" border="0">
				<tr>
				<td width="25%">
				<input type="radio" name="nontrade" id="noninter" value="NON-INTERCOMPANY"> Non-Intercompany<br>
				<input type="radio" name="nontrade" value="RELATED OR INTERCOMPANY"> Related or Inter company<br>
				<input type="radio" name="nontrade" value="EMPLOYEE"> Employee<br>
				</td>
				<td width="50%">
				<input type="radio" name="nontrade" value="MRO(MAXIMO/JDE)"> MRO(Maximo/JDE)<br>
				<input type="radio" name="nontrade" value="TAX ID OR SS#"> Tax ID or SS# (W-9 Required)<br>
				<input type="radio" name="nontrade" value="OTM"> OTM<br>
				</td>
				</tr>
				</table>
				</fieldset><br>
			<div id="tos">	
			<fieldset>
				<legend><font size="2" ><b>Non-Trade - Type of service </b></font></legend>
				<table width="100%"  cellpadding="10" cellspacing="0" border="0">
				<td width="30%">
				<input type="radio" name="nontradeTOS" value="GOODS"> Goods<br>
				<input type="radio" name="nontradeTOS" value="GENERAL SERVICES"> General Services<br>
				<input type="radio" name="nontradeTOS" value="OTHER"> Other<input type="text" name="other" /><br>
				</td>
				<td width="30%">
				<input type="radio" name="nontradeTOS" value="PROFESSIONAL SVC (LEGAL, CPA ETC)"> Professional Svc (Legal, CPA etc)<br>
				<input type="radio" name="nontradeTOS" value="MEDICAL/HEALTH CARE PAYMENTS"> Medical/Health Care Payments<br>
				<input type="radio" name="nontradeTOS" value="UTILITIES"> Utilities<br>
				</td>
				<td width="25%">
				<input type="radio" name="nontradeTOS" value="EDUCATION"> Education<br>
				<input type="radio" name="nontradeTOS" value="DONATION/CONTRIBUTION"> Donation/Contribution<br>
				<input type="radio" name="nontradeTOS" value="REIMBURSEMENT-VEHICLE DAMAGE"> Reimbursement-vehicle Damage<br>
				</td>
				</tr>
				</table>
					
				</fieldset><br>
				</div>	
				<script>			   
					$("#noninter").click(function(){
							if (this.id == "noninter")
								$("#tos").show();							
							else
								$("#tos").hide();							
						});
					</script>
				
				
				<fieldset >
				<legend><font size="2" ><b>Transaction Type </b></font></legend>
				<table width="100%" cellpadding="10" cellspacing="0" border="0">
				<tr><td width="15%">
				<input type="radio" name="trantype"  id="purchase" value="PURCHASE"/> Purchase<br>
				</td>
				<td width="15%">
				<input type="radio" name="trantype"  id="sale" value="SALE"/> Sale<br>
				</td>
				<td width="15%">
				<input type="radio" name="trantype"  id="both" value="PURCHASE/SALE"/> Both<br>
				</td>
				</tr>
				</table>
				</fieldset><br>
			
			<table>
			
			
			<tr><td><br></td></tr>
			<tr><td><br></td></tr>
			
	<!-- *********************************Mailing Address *************************************************************-->		
			 <div id="legaladdress">
			<tr>
			 
				<tr colspan=2><td></td><td><h2>Legal Address</h2></td></tr>
				<td>Name: </td>
				<td><input type="text" name="name"  id="name" size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
			</tr>
			<tr>
				<td>Address: </td>
				<td><input type="text" name="address"   id="address" size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="text" name="address1"  id="address1" size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
			</tr>
			<tr>
				<td>City :</td>
				<td><input type="text" name="City" id="City" size="35" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
			</tr>
			
			<tr>
				<?php $xml = simplexml_load_file("../xml/states.xml");?>
				<td>State:</td>
				<td><select type="text" name="State" id="State" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
					<option></option>
				<?php foreach ($xml->children() as $child){echo "<option> " . $child . "</option>" ."<br />";} ?>
				<tr>
					<td>Mail Code:</td> 
					<td><input type="text" name="zip" id="zip" size="6" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				</tr>	
				
			</tr>
			<tr>
				<?php $xml = simplexml_load_file("../xml/countries.xml");?>
				<td>Country :</td>
				<td><select type="text" name="country" id="country" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
					<option></option>
					<?php foreach ($xml->children() as $child){echo "<option> " . $child . "</option>" ."<br />";} ?>
				</td>
			</tr>
			</div>
			<tr><td><br></td></tr>
			
		<!-- ********************************* Remit To Address *************************************************************-->		
			<div id="baddress">	
				<tr id="RemitTo"><td></td><td><h2>Remit To</h2> </td> <td><input type="checkbox" name="remittosame" id="RemitTosame" onClick="same_as_billing()" />Same as Legal</td>
					<script>			   
					$("#purchase, #sale, #both").click(function(){
							if (this.id == "sale")
								$("#RemitTo").hide();							
							else if (this.id == "purchase" || this.id == "both")
								$("#RemitTo").show();
						});
					</script>
										
				</tr>
			<tr id="RemitToName">
				<td>Name: </td>
				<td><input type="text" name="RemitToName"  id="RemitToName" size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				
				<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitToName").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitToName").show();
														
					});
				</script>
				<script>			   
				$("#remittosameas").click(function(){
					$("#RemitToNameText").disabled = $(this).is(":checked");
				});

				</script>
			</tr>
			<tr id="RemitTomailaddress">
				<td>Address: </td>
				<td><input type="text" name="RemitToAddress" id="RemitToAddress" size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitTomailaddress").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitTomailaddress").show();
														
					});
				</script>
			</tr>
			<tr id="RemitTomailaddress1">
				<td></td>
				<td><input type="text" name="RemitToAddress1"  id="RemitToAddress1" size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitTomailaddress1").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitTomailaddress1").show();
													
					});
				</script>
			</tr>
			<tr id="RemitToCity">
				<td>City :</td>
				<td><input type="text" name="RemitToCity" id="RemitToCity" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitToCity").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitToCity").show();
													
					});
				</script>
			</tr>
			<tr id="RemitToState">
				<?php $xml = simplexml_load_file("../xml/states.xml");?>
				<td>State:</td>
				<td><select type="text" name="RemitToState" id="RemitToState" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
					<option></option>
				<?php foreach ($xml->children() as $child){echo "<option> " . $child . "</option>" ."<br />";} ?>
				
				<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitToState").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitToState").show();
												
					});
				</script>
				
			</tr>
			<tr id="RemitToZip">
					<td>Mail Code:</td>
					<td><input type="text" name="RemitToZip" id="RemitToZip" size="6" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitToZip").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitToZip").show();
													
					});
				</script>	
			</tr>
			<tr id="RemitToCountry">
				<?php $xml = simplexml_load_file("../xml/countries.xml");?>
				<td>Country :</td>
				<td><select type="text" name="RemitToCountry" id="RemitToCountry" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
					<option></option>
					<?php foreach ($xml->children() as $child){echo "<option> " . $child . "</option>" ."<br />";} ?>
				</td>
			
			
		<script>			   
				$("#purchase, #sale, #both").click(function(){
						if (this.id == "sale")
							$("#RemitToCountry").hide();							
						else if (this.id == "purchase" || this.id == "both")
								$("#RemitToCountry").show();							
					});
		</script>
				</tr>
				
			</div>
	
			<tr><td><br></td></tr>
			
		<!-- ********************************* Bill To Address *************************************************************-->		
			<tr id="BillTo"><td></td><td><h2>Bill To</h2></td> <td><input type="checkbox" name="billtosame"  id="BillTosame" onClick="same_as_billing()"/>Same as Legal</td>
					<script>			   
					$("#purchase, #sale").click(function(){
							if (this.id == "purchase")
								$("#BillTo").hide();							
							else
								$("#BillTo").show();							
						});
					</script>
			<tr id="BillToName">
				
				<td>Name: </td>
				<td><input type="text" name="BillToName"  size="50" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				
				<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillToName").hide();							
						else
							$("#BillToName").show();							
					});
				</script>
			</tr>
			<tr id="BillTomailaddress">
				<td>Address: </td>
				<td><input type="text" name="BillToAddress"  size="35" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillTomailaddress").hide();							
						else
							$("#BillTomailaddress").show();							
					});
				</script>
			</tr>
			<tr id="BillTomailaddress1">
				<td></td>
				<td><input type="text" name="BillToAddress1"  size="35" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillTomailaddress1").hide();							
						else
							$("#BillTomailaddress1").show();							
					});
				</script>
			</tr>
			<tr id="BillToCity">
				<td>City :</td>
				<td><input type="text" name="BillToCity" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();" ></td>
				<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillToCity").hide();							
						else
							$("#BillToCity").show();							
					});
				</script>
			</tr>
			<tr id="BillToState">
				<?php $xml = simplexml_load_file("../xml/states.xml");?>
				<td>State:</td>
				<td><select type="text" name="BillToState" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
					<option></option>
				<?php foreach ($xml->children() as $child){echo "<option> " . $child . "</option>" ."<br />";} ?>
								<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillToState").hide();							
						else
							$("#BillToState").show();							
					});
				</script>
				
			</tr>
			<tr id="BillToZip">
					<td>Mail Code:</td>
					<td><input type="text" name="BillToZip"  size="6" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
				<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillToZip").hide();							
						else
							$("#BillToZip").show();							
					});
				</script>	
			</tr>
			<tr id="BillToCountry">
				<?php $xml = simplexml_load_file("../xml/countries.xml");?>
				<td>Country :</td>
				<td><select type="text" name="BillToCountry" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
					<option></option>
					<?php foreach ($xml->children() as $child){echo "<option> " . $child . "</option>" ."<br />";} ?>
				</td>
			
			
		<script>			   
				$("#purchase, #sale").click(function(){
						if (this.id == "purchase")
							$("#BillToCountry").hide();							
						else
							$("#BillToCountry").show();							
					});
		</script>
				</tr>
				
		<tr><td><br></td></tr>
		
		
				
				
		
		
			
			<tr><td><br></td></tr>
			<tr><td><br></td></tr>
			<tr><td><br></td></tr>
			<tr>
				<td>Contact :</td>
				<td><input type="text" name="contact" id="contact" size="35"></td>
			</tr>
			<tr>
				<td> Contact Telephone :</td>
				<td><input type="text" name="Telephone" id="telephone" size="35"></td>
			</tr>
	
			
			<tr>
				<td>Comments: </td>
				<td><textarea rows="5" cols="30" name="comments"></textarea></td>
			</tr>
			<tr>
				<td>Submitted By:</td>
				<td><input type="text" name="from" size="35"></td><td>ex: someone@omnisource.com</td>
			</tr>
			
			
			
			</table>
			
			<input type="submit" value="Send">
			
			<script>onload= document.addressform.reset();</script>	
	  </form>
	  
	
	</div>

	<div id="secondarycontent">

		
	
		

		

	</div>

	<div class="clearit"></div>

</div>

<div id="footer">
	&copy; 2011, 2012 Omnisource. 
</div>


</body>
</html>
